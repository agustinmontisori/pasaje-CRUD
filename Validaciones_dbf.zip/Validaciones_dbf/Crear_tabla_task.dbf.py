import dbf
import os
from datetime import datetime

# Definir la ruta del archivo DBF
ruta_dbf = '/home/u_com108/Desarrollos/Validaciones_dbf/task.dbf'

# Crear una nueva tabla si no existe
if not os.path.exists(ruta_dbf):
    # Definir la tabla con la estructura correcta
    nueva_tabla = dbf.Table(
        ruta_dbf, 'id N(3,0); title C(10); descrip C(10); created_at D; datecomp D; important L; user_id N(4,0)')
    nueva_tabla.open(mode=dbf.READ_WRITE)
    nueva_tabla.close()
    print('La tabla fue creada exitosamente')
else:
    print('La tabla ya existe')

# Abrir la tabla
nueva_tabla = dbf.Table(ruta_dbf)

# Abrir el archivo DBF
print(nueva_tabla.field_names)

"""
# Imprimir los primeros 5 registros
for i, record in enumerate(nueva_tabla[:5], start=1):
    print(f'Registro {i}: {record}')
"""
    
# Cerrar la tabla
nueva_tabla.close()
