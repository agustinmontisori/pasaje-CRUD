import dbf

# Identificar ruta de archivo a leer y el registro especifico a mostrar
nombre_archivo = 'Arancel'
ruta_archivo = nombre_archivo + '.dbf'
num_registro = 260 #por un momento la tabla Arancel original mostraba solo 193 registros desde python, en VisualFox tiene 260

# Abre el archivo DBF
tabla = dbf.Table(ruta_archivo)
tabla.open()

"""
# Convertir tabla a lista para acceder a registros especificos mediante indice
tabla_lista = list(tabla)
"""

count = 0
# Itera sobre los registros y muestra los datos
for registro in tabla:
    count += 1
    print(f"El registro numero {count} de la tabla {ruta_archivo} es: "
      , registro)

"""
#Acceder a datos específicos (por ejemplo, el primer registro)
primer_registro = next(iter(tabla))
print("El primer registro de la tabla es: ", primer_registro)
"""
"""
#Acceder al registro nummero num_registro
print(f"El registro numero {num_registro+1} de la tabla {ruta_archivo} es: "
      , tabla_lista[num_registro])
"""

# Cerrar la tabla
tabla.close()


