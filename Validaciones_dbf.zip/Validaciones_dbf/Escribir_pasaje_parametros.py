# Script para traer parametros desde otro proyecto
import sys
import dbf

# Obtener los argumentos de línea de comandos
args = sys.argv

# El primer argumento (args[0]) es el nombre del script en sí
# Los argumentos restantes son los que pasamos desde la línea de comandos
if len(args) > 1:
    for i, arg in enumerate(args[1:], start=1):
        print(f"Parámetro {i}: {arg}")
        print(type(arg))
else:
    print("No se han pasado parámetros.")

# Identificar ruta de archivo a escribir
ruta_archivo = '/home/u_com108/Desarrollos/Validaciones_dbf/task.dbf'
       
# Abre el archivo DBF
tabla = dbf.Table(ruta_archivo)
tabla.open(dbf.READ_WRITE)

"""
# Convertir tabla a lista para acceder a registros especificos mediante indice
tabla_lista = list(tabla)
"""

# Parámetros que se pasan desde otro proyecto
title = args[1]
description = args[2]
print('el tipo de dato de titulo es: ', type(title))
print('el tipo de dato de descripcion es: ', type(description))

# Definir los datos del nuevo registro
new_record = {
    'title': title,
    'descrip': description,
    'created_at': None,
    'datecomp': None,
    'important': False,
    'user_id': None  # Aquí debes poner el número de usuario correspondiente
}

# Agregar el nuevo registro a la tabla


# Insertar un nuevo registro en la tabla
try:
    tabla.append(new_record)
    print(f"Nuevo registro insertado: {title}, {description}")
except Exception as e:
    print(f"Error al insertar registro: {e}")


# Cerrar la tabla
tabla.close()

