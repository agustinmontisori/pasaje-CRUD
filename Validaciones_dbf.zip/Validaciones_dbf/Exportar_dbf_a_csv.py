import dbf
import csv

#identificar ruta de archivos
nombre_archivo = 'Arancel'
ruta_archivo = nombre_archivo + '.dbf'  
ruta_csv = nombre_archivo+".csv"

# Abre el archivo DBF
tabla = dbf.Table(ruta_archivo)
tabla.open()

# Obtener los nombres de las columnas
columnas = tabla.field_names

# Abrir el archivo CSV para escritura
with open(ruta_csv, mode='w', newline='', encoding='utf-8') as archivo_csv:
    escritor_csv = csv.writer(archivo_csv)

    # Escribir la cabecera
    escritor_csv.writerow(columnas)

    # Iterar sobre los registros de la tabla y escribirlos en el CSV
    for record in tabla:
        fila = [record[f] for f in columnas]
        escritor_csv.writerow(fila)

# Cerrar la tabla
tabla.close()