# Script para traer parametros desde otro proyecto
import sys
import dbf

# Obtener los argumentos de línea de comandos
num_registro = 1

# Identificar ruta de archivo a escribir
ruta_archivo = '/home/u_com108/Desarrollos/Validaciones_dbf/task.dbf'
       
# Abre el archivo DBF
tabla = dbf.Table(ruta_archivo)
tabla.open()

"""
count = 0
# Itera sobre los registros y muestra los datos
for registro in tabla:
    count += 1
    print(registro)
"""

registro = [tabla[num_registro].ID, tabla[num_registro].TITLE, tabla[num_registro].DESCRIP, tabla[num_registro].CREATED_AT, tabla[num_registro].DATECOMP, tabla[num_registro].IMPORTANT, tabla[num_registro].USER_ID]

print(registro)

# Cerrar la tabla
tabla.close()