import dbf

# Identificar ruta de archivo a leer y el registro especifico a mostrar
nombre_archivo = 'Arancel'
ruta_archivo = nombre_archivo + '.dbf'
num_registro = 1            

# Abre el archivo DBF
tabla = dbf.Table(ruta_archivo)
tabla.open(dbf.READ_WRITE)

# Convertir tabla a lista para acceder a registros especificos mediante indice
tabla_lista = list(tabla)

# Modificar un registro de la tabla
for record in tabla:
    if record.ARANNOMBRE.strip() == "Amalgama / Composite cavidad comp.":
        print(record)
        with record:
            record.ARANPRINOS = 11429.0
            print("El registro fue modificado correctamente", record)
            break

# Cerrar la tabla
tabla.close()