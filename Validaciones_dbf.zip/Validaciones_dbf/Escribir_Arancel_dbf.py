import dbf

# Identificar ruta de archivo a leer y el registro especifico a mostrar
ruta_archivo = 'Arancel.dbf'
num_registro = 1            

# Abre el archivo DBF
tabla = dbf.Table(ruta_archivo)
tabla.open(dbf.READ_WRITE)

# Convertir tabla a lista para acceder a registros especificos mediante indice
tabla_lista = list(tabla)

# Agregar un nuevo registro a la tabla
#tabla.append(('Sol Perez', 31, dbf.Date(1993, 5, 15)))
tabla.append(('02.02', '*', 'Lalalala', '*', 11429.0, '*', 19493.0, '*', 'Lalalala', '*', 2, False, '', None, '*', '', '*', '', 2, 2, True, ''))

# Cerrar la tabla
tabla.close()