import dbf
import os

# Definir la ruta del archivo DBF
ruta_dbf = '/home/u_com108/Desarrollos/Validaciones_dbf/nueva_tabla.dbf'

# Crear una nueva tabla si no existe
if not os.path.exists(ruta_dbf):
    nueva_tabla = dbf.Table(ruta_dbf,'nombre C(20); edad N(3,0); nacimiento D')
    nueva_tabla.open(dbf.READ_WRITE)
    nueva_tabla.close()
    print('La tabla fue creada exitosamente')
else:
    print('La tabla ya existe')

# Abrir la tabla en modo escritura
nueva_tabla = dbf.Table(ruta_dbf,'nombre C(20); edad N(3,0); nacimiento D')

# Abrir la tabla en modo escritura
nueva_tabla.open(dbf.READ_WRITE)

# Abrir el archivo DBF
print(nueva_tabla.field_names)

# Imprimir los primeros 5 registros
for i, record in enumerate(nueva_tabla[:5], start=1):
    print(f'Registro {i}: {record}')

# Cerrar la tabla
nueva_tabla.close()