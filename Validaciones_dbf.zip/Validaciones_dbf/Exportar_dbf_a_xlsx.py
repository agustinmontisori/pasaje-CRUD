import dbf
import openpyxl

#identificar ruta de archivos
nombre_archivo = 'Arancel'
ruta_archivo = nombre_archivo + '.dbf'
ruta_xslx = nombre_archivo+'.xlsx'

# Abre el archivo DBF
tabla = dbf.Table(ruta_archivo)
tabla.open()

# Crear un nuevo libro de Excel
libro = openpyxl.Workbook()
hoja = libro.active
hoja.title = nombre_archivo

# Obtener los nombres de las columnas
columnas = tabla.field_names

# Escribir la cabecera en la hoja de Excel
hoja.append(columnas)

# Iterar sobre los registros de la tabla y escribirlos en la hoja de Excel
for record in tabla:
    fila = [record[col] for col in columnas]
    hoja.append(fila)

# Guardar el archivo Excel
libro.save(ruta_xslx)

# Cerrar la tabla
tabla.close()