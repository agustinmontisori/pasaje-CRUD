import dbf

# Identificar ruta de archivo a leer y el registro especifico a mostrar
nombre_archivo = 'task'
ruta_archivo = nombre_archivo + '.dbf'
num_registro = 1            

# Abre el archivo DBF
tabla = dbf.Table(ruta_archivo)
tabla.open(dbf.READ_WRITE)

# Convertir tabla a lista para acceder a registros especificos mediante indice
tabla_lista = list(tabla)

"""
# Agregar un nuevo registro a la tabla
tabla.append(('Lectura bidireccional', 'Lectura bidireccional en dbf y sqlite', dbf.Date(2024, 7, 08),dbf.Date(),False,3))
"""

# Definir los datos del nuevo registro
new_record = {
    'id': 2,
    'title': 'Lectura',
    'descrip': 'Bidir',
    'created_at': dbf.Date(2024, 7, 8),
    'datecomp': None,
    'important': False,
    'user_id': 3  # Aquí debes poner el número de usuario correspondiente
}

# Agregar el nuevo registro a la tabla
tabla.append(new_record)

# Cerrar la tabla
tabla.close()