import dbf

#identificar ruta de archivos
nombre_archivo = 'Arancel'
ruta_archivo = nombre_archivo + '.dbf'          

# Abre el archivo DBF
tabla = dbf.Table(ruta_archivo)
tabla.open(dbf.READ_WRITE)

# Modificar un registro de la tabla para que se marque como borrado logico
for record in tabla:
    if record.NOMBRE.strip() == "Sol Perez":
        with record:
            dbf.delete(record)
            break

# Actualizar la tabla para eliminar registros que estan marcados con borrado logico
#tabla.pack()

# Cerrar la tabla
tabla.close()